# payroll-management-system
This is a Spring Boot Application for Payroll Management System

Single Login : Admin

The Admin can add Employee and Manage them.

At Every month the Admin can generate Payroll and mail or print it.

Use your smtp credentials in the SMTP code.
